function change() {
  document.body.innerHTML = ""
  
  var header = document.createElement("h1");
  header.id = "head";
  header.innerHTML += 'ORGANIZED SPLACK TO-DO LIST'; document.body.append(header);
  
  var div_for_tmrw = document.createElement("div");
  div_for_tmrw.id = "tmrw";
  div_for_tmrw.innerHTML += 'Due Tomorrow:'; document.body.append(div_for_tmrw);
  var divA = document.createElement("div");
  divA.id = "text-output";
  document.body.append(divA);
  var div_for_later = document.createElement("div");
  div_for_later.id = "late";
  div_for_later.innerHTML += 'Due at a Later Date:';
  document.body.append(div_for_later);
  var divS = document.createElement("div");
  divS.id = "text-output2";
  document.body.append(divS);
}

//var hList = ['Do yoga for five minutes!', 'Go make a healthy snack!', 'Meditate for five minutes!', 'Get up and stretch!', 'Go for a run!', 'Read a book!', 'Take a walk!']

//function lifestyle() {
  //var rand = Math.floor(Math.random() * 4);
  //var msg = hList[rand];
  //document.getElementById("life").innerHTML = msg;
//}

